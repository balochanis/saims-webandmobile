var items = [{
    id: "041",
    name: 'item 021',
    image: 'furniture.jpg',
        price:1220,
    quantity: 0
}, {
    id: "042",
    name: 'item 022',
    image: 'furniture.jpg',
        price:1365,
    quantity: 0

}, {
    id: "043",
    name: 'item 023',
    image: 'furniture.jpg',
        price:1000,
    quantity: 0

}, {
    id: "044",
    name: 'item 024',
    image: 'furniture.jpg',
        price:2500,
    quantity: 0

}, {
    id: "045",
    name: 'item 025',
    image: 'furniture.jpg',
        price:3620,
    quantity: 0

}, {
    id: "046",
    name: 'item 026',
    image: 'furniture.jpg',
        price:3550,
    quantity: 0

}, {
    id: "047",
    name: 'item 027',
    image: 'furniture.jpg',
        price:2145,
    quantity: 0

}, {
    id: "048",
    name: 'item 028',
    image: 'furniture.jpg',
        price:3665,
    quantity: 0

}, {
    id: "049",
    name: 'item 029',
    image: 'furniture.jpg',
        price:9554,
    quantity: 0

}, {
    id: "050",
    name: 'item 030',
    image: 'furniture.jpg',
        price:3654,
    quantity: 0

}];