var items = [{
    id: "002",
    name: 'item 001',
    image: 'dummy.png',
        price:90,
    quantity: 0

}, {
    id: "003",
    name: 'item 002',
    image: 'dummy.png',
        price:65,
    quantity: 0

}, {
    id: "004",
    name: 'item 003',
    image: 'dummy.png',
        price:45,
    quantity: 0

}, {
    id: "005",
    name: 'item 004',
    image: 'dummy.png',
        price:90,
    quantity: 0

}, {
    id: "006",
    name: 'item 005',
    image: 'dummy.png',
        price:54,
    quantity: 0

}, {
    id: "007",
    name: 'item 006',
    image: 'dummy.png',
        price:45,
    quantity: 0

}, {
    id: "008",
    name: 'item 007',
    image: 'dummy.png',
        price:90,
    quantity: 0

}, {
    id: "009",
    name: 'item 008',
    image: 'dummy.png',
        price:87,
    quantity: 0

}, {
    id: "010",
    name: 'item 009',
    image: 'dummy.png',
        price:12,
    quantity: 0

}];